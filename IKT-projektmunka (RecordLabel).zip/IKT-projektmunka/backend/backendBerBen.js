const express = require("express");
const app = express();
app.set("view engine", "ejs");


// API végpontok
app.get("/api/users", (req, res) => {
  // Felhasználók lekérdezése az adatbázisból
});

app.post("/api/users", (req, res) => {
  // Új felhasználó létrehozása az adatbázisban
});

app.get("/", (req, res) => {
  res.render("indexBerBen.ejs")
});

app.get("/homeMachines", (req, res) => {
  res.render("homeMachines.ejs")
});

app.get("/login", (req, res) => {
  res.render("loginBerBen.ejs")
});

app.get("/onlineSupermarket", (req, res) => {
  res.render("onlineSupermarket.ejs")
});

app.get("/smartGadgets", (req, res) => {
  res.render("smartGadgets.ejs")
});

app.get("/toysAndBabyDepartment", (req, res) => {
  res.render("toysAndBabyDepartment.ejs")
});

// API indítása
const port = 3000;
app.listen(port, () => {
  console.log(`API fut a ${port} porton.`);
});


