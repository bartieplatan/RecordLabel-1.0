// HTML elemek
const navbar = document.querySelector(".navbar");
const navbarBrand = document.querySelector(".navbar-brand");
const navbarToggler = document.querySelector(".navbar-toggler");
const navbarSupportedContent = document.querySelector(".navbar-supported-content");

// Navbar működésének beállítása
navbarToggler.addEventListener("click", () => {
  navbarSupportedContent.classList.toggle("collapse");
});

// Navbar brand megjelenítése
navbarBrand.innerHTML = "BerBen társaság";